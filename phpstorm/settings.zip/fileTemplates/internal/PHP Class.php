<?php

#if (${NAMESPACE})
namespace ${NAMESPACE};

#end
/**
 * Class ${NAME}
 *
 * @package \\${NAMESPACE}
 */
class ${NAME} {

}